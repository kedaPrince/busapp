<?php

namespace App\Http\Resources\v1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'seatsBooked' => $this->seats_booked,
            'fromCode' => $this->from_code,
            'fromName' => $this->from_name,
            'toCode' => $this->to_code,
            'toName' => $this->to_name,
            'leavingTime' => $this->leaving_time,
            'date' => $this->date,
            'price' => $this->price,
            'departureDate' => $this->departure_date,
            'departureTime' => $this->departure_time,
            'arrivalDate' => $this->arrival_date,
            'arrivalTime' => $this->arrival_time,
            'travelHours' => $this->travel_hours,
            
        ];
    
    }
}
