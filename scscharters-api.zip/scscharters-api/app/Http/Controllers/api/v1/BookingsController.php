<?php

namespace App\Http\Controllers\api\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Bookings;
use Illuminate\Support\Facades\Log;
use App\Filters\v1\BookingsFilter;
use App\Http\Resources\v1\BookingsResource;
use App\Http\Resources\v1\BookingsCollection;
use App\Http\Requests\StoreBookingsRequest;
use App\Http\Requests\UpdateBookingsRequest;

class BookingsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $filter = new BookingsFilter();
        $filterItems = $filter->transform($request);

        if(count($filterItems)==0){
            return new BookingsCollection(Bookings::paginate());
        }else{
            $bookings = Bookings::where($filterItems)->paginate();
            return new BookingsCollection($bookings->appends($request->query()));
           
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->all(); // Get all the request data

        $bookings = new Bookings();
        $bookings->seats_booked = $data['seats_booked'];
        $bookings->from_code = $data['from_code'];
        $bookings->from_name = $data['from_name'];
        // Repeat for other fields...
        $bookings->to_code = $data['to_code'];
        $bookings->to_name = $data['to_name'];
        $bookings->date = $data['date'];
        $bookings->leaving_time = $data['leaving_time'];
        $bookings->price = $data['price'];
        $bookings->departure_date = $data['departure_date'];
        $bookings->departure_time = $data['departure_time'];
        $bookings->arrival_date = $data['arrival_date'];
        $bookings->arrival_time = $data['arrival_time'];
        $bookings->travel_hours = $data['travel_hours'];
    
      
     
    
        // Save the bookings
        $bookings->save();
    
        return new BookingsResource($bookings);
    }
    

    /**
     * Display the specified resource.
     */
    public function show(Bookings $bookings)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Bookings $bookings)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateBookingsRequest $request, Bookings $bookings)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Bookings $bookings)
    {
        //
    }
}
