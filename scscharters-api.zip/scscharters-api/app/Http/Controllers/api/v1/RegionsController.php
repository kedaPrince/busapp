<?php

namespace App\Http\Controllers\api\v1;

use Illuminate\Http\Request;
use App\Models\Regions;
use Illuminate\Support\Facades\Log;

use App\Http\Controllers\Controller;
use App\Http\Resources\v1\RegionsResource;
use App\Http\Resources\v1\RegionsCollection;
use App\Filters\v1\RegionsFilter;
use App\Http\Requests\v1\StoreRegionsRequest;
use App\Http\Requests\v1\UpdateRegionsRequest;

class RegionsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
 
    public function index(Request $request)
    {
        $filter = new RegionsFilter();
        $filterItems = $filter->transform($request);

        if(count($filterItems)==0){
            return new RegionsCollection(Regions::paginate());
        }else{
            $regions = Regions::where($filterItems)->paginate();
            return new RegionsCollection($regions->appends($request->query()));
           
        }
    }

    public function store(Request $request)
    {
        $data = $request->all(); // Get all the request data
    
        // Create a new Regions instance and fill it with data
        $region = new Regions();
        $region->from_code = $data['from_code'];
        $region->from_name = $data['from_name'];
        // Repeat for other fields...
        $region->to_code = $data['to_code'];
        $region->to_name = $data['to_name'];
        $region->date = $data['date'];
        $region->leaving_time = $data['leaving_time'];
        $region->price = $data['price'];
        $region->departure_date = $data['departure_date'];
        $region->departure_time = $data['departure_time'];
        $region->arrival_date = $data['arrival_date'];
        $region->arrival_time = $data['arrival_time'];
        $region->travel_hours = $data['travel_hours'];
    
      
     
    
        // Save the region
        $region->save();
    
        return new RegionsResource($region);
    }
    

    public function show($id)
    {
        $region = Regions::find($id);
        if (!$region) {
            return response()->json(['error' => 'Region not found'], 404);
        }
    
        return new RegionsResource($region);
    }


    public function update(UpdateRegionsRequest $request, Regions $region)
{
    $data = $request->all();

    // Update the attributes of the existing region with the new data
    $region->update([
        'from_code' => $data['from_code'],
        'from_name' => $data['from_name'],
        // Repeat for other fields...
        'to_code' => $data['to_code'],
        'to_name' => $data['to_name'],
        'date' => $data['date'],
        'leaving_time' => $data['leaving_time'],
        'price' => $data['price'],
        'departure_date' => $data['departure_date'],
        'departure_time' => $data['departure_time'],
        'arrival_date' => $data['arrival_date'],
        'arrival_time' => $data['arrival_time'],
        'travel_hours' => $data['travel_hours'],
    ]);

    // Optionally, you can check if the update was successful
    if ($region->wasChanged()) {
        return new RegionsResource($region);
    } else {
        // Handle the case where no changes were made (e.g., return a response indicating no changes)
        return response()->json(['message' => 'No changes were made.'], 200);
    }
}


    

    
    

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Regions $regions)
    {
        //
    }
}
