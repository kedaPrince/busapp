<?php

namespace App\Http\Requests\v1;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
class UpdateRegionsRequest extends FormRequest
{
  public function authorize(): bool
  {
      return true;
  }

  public function rules()
  {
      $method = $this->method();
      if ($method == 'PUT' || $method == 'PATCH') {
          return [
              // Define rules for fields that are required for full updates
              'from_code' => ['required'],
              'from_name' => ['required'],
              // Repeat for other fields...
              'to_code' => ['required'],
              'to_name' => ['required'],
              'date' => ['required', 'date', 'date_format:Y-m-d'],
              'leaving_time' => ['required', 'date_format:H:i:s'],
              'price' => ['required'],
              'departure_date' => ['required', 'date', 'date_format:Y-m-d'],
              'departure_time' => ['required', 'date_format:H:i:s'],
              'arrival_date' => ['required', 'date', 'date_format:Y-m-d'],
              'arrival_time' => ['required', 'date_format:H:i:s'],
              'travel_hours' => ['required'],
          ];
         
      } else {
          return [
              // Define rules for fields that can be updated in a partial manner
              'from_code' => ['sometimes', 'required'],
              'from_name' => ['sometimes', 'required'],
              // Repeat for other fields...
              'to_code' => ['sometimes', 'required'],
              'to_name' => ['sometimes', 'required'],
              'date' => ['sometimes', 'required', 'date', 'date_format:Y-m-d'],
              'leaving_time' => ['sometimes', 'required', 'date_format:H:i:s'],
              'price' => ['sometimes', 'required'],
              'departure_date' => ['sometimes', 'required', 'date', 'date_format:Y-m-d'],
              'departure_time' => ['sometimes', 'required', 'date_format:H:i:s'],
              'arrival_date' => ['sometimes', 'required', 'date', 'date_format:Y-m-d'],
              'arrival_time' => ['sometimes', 'required', 'date_format:H:i:s'],
              'travel_hours' => ['sometimes', 'required'],
          ];
         
      }
  }
}
