<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
class StoreRegionsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'from_code' => ['required'],
            'from_name' => ['required'],
            'to_code' => ['required'],
            'to_name' => ['required'],
            'date' => ['required', 'date', 'date_format:Y-m-d'],
            'leaving_time' => ['required', 'date_format:H:i:s'],
            'price' => ['required'],
            'departure_date' => ['required', 'date', 'date_format:Y-m-d'],
            'departure_time' => ['required', 'date_format:H:i:s'],
            'arrival_date' => ['required', 'date', 'date_format:Y-m-d'],
            'arrival_time' => ['required', 'date_format:H:i:s'],
            'travel_hours' => ['required'],
        ];
    }
    

    protected function prepareForValidation()
{
    $this->merge([
        'from_code' => $this->fromCode,
        'from_name' => $this->fromName,
        'to_code' => $this->toCode,
        'to_name' => $this->toName,
        'leaving_time' => $this->leavingTime,
        'departure_date' => $this->departureDate,
        'departure_time' => $this->departureTime,
        'arrival_date' => $this->arrivalDate,
        'arrival_time' => $this->arrivalTime,
        'travel_hours' => $this->travelHours,
    ]);
}

}

