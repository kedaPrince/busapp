<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bookings extends Model
{
    use HasFactory;
    protected $fillable = [
        'seats_booked',
        'from_code',
        'from_name',
        'to_code',
        'to_name',
        'leaving_time',
        'date',
        'departure_date',
        'departure_time',
        'price',
        'arrival_date',
        'arrival_time',
        'travel_hours'
    ];
}
