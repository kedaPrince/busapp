<?php

namespace App\Filters\v1;

use Illuminate\Http\Request;
use App\Filters\ApiFilter;

class BookingsFilter extends ApiFilter{
    protected $safeParms =[
        'seatsBooked' =>['eq','gte','lt','lte','gt'],
        'fromCode' =>['eq','gte','lt','lte','gt'],
        'fromName' =>['eq','gte','lt','lte','gt'],
        'toCode' =>['eq','gte','lt','lte','gt'],
        'toName' =>['eq','gte','lt','lte','gt'],
        // 'leaving_time' =>[],
        // 'date' =>[],
        'departure_date' =>['eq','gte','lt','lte','gt'],
        // 'departure_time' =>[],
        // 'price' =>[],
        // 'arrival_date' =>[],
        // 'arrival_time' =>[],
        // 'travel_hours'=>[]
    ];
    protected $columnMap =[
        'seatsBooked' => 'seats_booked',
        'fromCode' => 'from_code',
        'fromName' => 'from_name',
        'toCode' => 'to_code',
        'toName' => 'to_name',
        'departureDate' =>'departure_date'
    ];

    protected $operatorMap =[
        'eq' =>'=',
        'lt' =>'<',
        'lte' =>'<=',
        'gt' =>'>',
        'gte' =>'>=',
        
    ];
}