<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Regions>
 */
class RegionsFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
      
        return [
            'from_code' => $this->faker->unique()->regexify('[A-Z]{3}'),
            'from_name' => $this->faker->city,
            'to_code' => $this->faker->unique()->regexify('[A-Z]{3}'),
            'to_name' => $this->faker->city,
           'leaving_time' => $this->faker->time(),
           'date' => $this->faker->date(),
           'departure_date' => $this->faker->date(),
           'departure_time' => $this->faker->time(),
           'arrival_date' => $this->faker->dateTime(),
           'arrival_time' => $this->faker->dateTime(),
           'travel_hours' => $this->faker->time(),
           'price' => $this->faker->randomFloat(2, 10, 100),


        ];
        
    }
}

